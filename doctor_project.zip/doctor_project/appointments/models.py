from django.db import models

class Doctor(models.Model):
    name = models.CharField(max_length=100)
    specialty = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    max_patients_per_day = models.PositiveIntegerField(default=10)
    #availability = models.JSONField(default=list)


    def __str__(self):
        return self.name

from django.db import models

class Availability(models.Model):
    doctor = models.ForeignKey('Doctor', on_delete=models.CASCADE)
    day_of_week = models.CharField(max_length=20)
    status = models.CharField(max_length=20)
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return f"{self.doctor} - {self.day_of_week}"


class Appointment(models.Model):
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    patient_name = models.CharField(max_length=100)



    def __str__(self):
        return f"{self.doctor.name} - {self.get_day_of_week_display()} ({self.start_time} to {self.end_time})"