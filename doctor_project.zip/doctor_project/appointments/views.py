from django.shortcuts import render

# Create your views here.

from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Doctor, Appointment, Availability
from .serializers import DoctorSerializer, AppointmentSerializer, AvailabilitySerializer
@api_view(['GET', 'POST'])
def doctor_list(request):
    if request.method == 'GET':
        doctors = Doctor.objects.all()
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = DoctorSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET'])
def doctor_detail(request, doctor_id):
    try:
        doctor = Doctor.objects.get(pk=doctor_id)
    except Doctor.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    serializer = DoctorSerializer(doctor)
    return Response(serializer.data)



@api_view(['GET', 'POST'])
def doctor_availability(request, doctor_id):
    if request.method == 'GET':
        try:
            # Retrieve availability data for the specified doctor_id
            availability_objects = Availability.objects.filter(doctor_id=doctor_id)
            if not availability_objects.exists():
                return Response({'error': 'No availability data found for this doctor'},
                                status=status.HTTP_404_NOT_FOUND)

            serializer = AvailabilitySerializer(availability_objects, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    elif request.method == 'POST':
        try:
            # Update availability data for the specified doctor_id
            data = request.data.get('availability')  # Retrieve the 'availability' data from request
            if not isinstance(data, list):  # Check if 'availability' data is a list
                return Response({'error': 'Invalid data format'}, status=status.HTTP_400_BAD_REQUEST)

            for day in data:
                day_of_week = day.get('day_of_week')
                availability_status = day.get('status')
                start_time = day.get('start_time')  # Retrieve start_time from the input data
                end_time = day.get('end_time')  # Retrieve end_time from the input data
                if day_of_week is not None and availability_status is not None and start_time is not None and end_time is not None:
                    availability, created = Availability.objects.update_or_create(
                        doctor_id=doctor_id,
                        day_of_week=day_of_week,
                        defaults={'status': availability_status, 'start_time': start_time, 'end_time': end_time}
                    )
                else:
                    return Response({'error': 'Invalid data format or missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

            return Response({'message': 'Availability updated successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def book_appointment(request):
    serializer = AppointmentSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)