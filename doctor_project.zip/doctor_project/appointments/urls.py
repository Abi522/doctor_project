from django.urls import path
from .views import doctor_list, doctor_detail, doctor_availability, book_appointment

urlpatterns = [
   # path('api/doctors/', create_doctor, name='create-doctor'),

    path('doctors/', doctor_list, name='doctor-list'),
    path('doctors/<int:doctor_id>/', doctor_detail, name='doctor-detail'),
    path('doctors/<int:doctor_id>/availability/', doctor_availability, name='doctor-availability'),
    path('appointments/book/', book_appointment, name='book-appointment'),
]
